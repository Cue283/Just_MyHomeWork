class Book {
  final String title;
  final String urlImage;

  const Book({
    required this.title,
    required this.urlImage,
  });
}

const allBooks = [
  Book(
      title: 'The Case Files of Lord El-Melloi II ',
      urlImage: 'https://upload.wikimedia.org/wikipedia/en/thumb/7/77/ElMelCaseFiles1.jpg/220px-ElMelCaseFiles1.jpg'),
  Book(
      title: 'Kara no Kyoukai ',
      urlImage: 'https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1327541639i/3511225.jpg'),
  Book(
      title: 'Fate/Zero Volume 1',
      urlImage: 'https://m.media-amazon.com/images/I/71HDP0bWJnL._SY342_.jpg'),
];
